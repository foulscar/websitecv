import boto3
import json
import os
from botocore.exceptions import ClientError
from decimal import Decimal
import datetime
from zoneinfo import ZoneInfo

# Custom JSON Encoder to handle Decimal types
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    # Initialize the DynamoDB client
    dynamodb = boto3.resource('dynamodb')

    # Reference to your DynamoDB table
    table_name = os.environ['DYNAMODB_TABLE_NAME']
    table = dynamodb.Table(table_name)

    # List of IDs to fetch
    ids_to_fetch = ['cloudfront_requests', 'dynamodb_readunits', 'dynamodb_writeunits', 'api_requests', 'api_backend_hits', 'api_backend_misses']
    keys_to_fetch = [{'ID': id} for id in ids_to_fetch]

    # Prepare the request for batch_get_item
    request = {
        table_name: {
            'Keys': keys_to_fetch
        }
    }

    try:
        # Batch get items
        response = dynamodb.batch_get_item(RequestItems=request)
        items = response['Responses'].get(table_name, [])

        # Fetch the item with ID 'timestamp' using the table reference
        timestamp_response = table.get_item(Key={'ID': "timestamp"})
        timestamp = timestamp_response.get('Item', None)

        if timestamp:
            starttime = timestamp.get('STARTTIME')
            endtime = timestamp.get('ENDTIME')
        else:
            starttime = None
            endtime = None

        # Get the current datetime
        # Timezone for New York
        new_york_tz = ZoneInfo("America/New_York")

        current_datetime = datetime.datetime.now(new_york_tz).strftime('%Y-%m-%d %H:%M:%S')


        # Prepare the response body
        response_body = {
            "items": items,
            "timestamp": {
                "STARTTIME": starttime,
                "ENDTIME": endtime
            },
            "getItemsTime": current_datetime
        }

        return response_body

    except ClientError as e:
        # Handle exceptions
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
