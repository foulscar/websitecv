import boto3
import logging
import os
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Get Environment Variables
    cloudfront_id = os.environ['CLOUDFRONT_ID']
    api_gateway_public_name = os.environ['API_GATEWAY_PUBLIC_NAME']
    api_gateway_private_name = os.environ['API_GATEWAY_PRIVATE_NAME']
    api_gateway_private_id = os.environ['API_GATEWAY_PRIVATE_ID']
    dynamodb_table_name = os.environ['DYNAMODB_TABLE_NAME']
    
    logger.info("Lambda function execution started")
    logger.info(f"Event: {event}")
    logger.info(f"Context: {context}")

    # Initialize the CloudWatch and DynamoDB clients
    cloudwatch = boto3.client('cloudwatch')
    dynamodb = boto3.resource('dynamodb')
    api_gateway = boto3.client('apigateway')  # Added API Gateway client

    # Reference to your DynamoDB table
    table = dynamodb.Table(dynamodb_table_name)

    # Define the time range for the last 24 hours
    # Timezone for New York
    new_york_tz = ZoneInfo("America/New_York")

    # Current time in New York
    end_time = datetime.now(new_york_tz)

    # Time 24 hours ago in New York
    start_time = end_time - timedelta(days=1)

    formatted_endtime = end_time.strftime('%Y-%m-%d %H:%M:%S')
    formatted_starttime = start_time.strftime('%Y-%m-%d %H:%M:%S')

    print("Start Time:", formatted_starttime)
    print("End Time:", formatted_endtime)

    # List of metrics to retrieve
    metrics = [
        {
            "ID": "cloudfront_requests",
            "Namespace": "AWS/CloudFront",
            "MetricName": "Requests",
            "Dimensions": [
                {
                    "Name": "DistributionId",
                    "Value": cloudfront_id
                },
                {
                    "Name": "Region",
                    "Value": "Global"
                }
            ]
        },
        {
            "ID": "dynamodb_readunits",
            "Namespace": "AWS/DynamoDB",
            "MetricName": "ConsumedReadCapacityUnits",
            "Dimensions": [
                {
                    "Name": "TableName",
                    "Value": dynamodb_table_name
                }
            ]
        },
        {
            "ID": "dynamodb_writeunits",
            "Namespace": "AWS/DynamoDB",
            "MetricName": "ConsumedWriteCapacityUnits",
            "Dimensions": [
                {
                    "Name": "TableName",
                    "Value": dynamodb_table_name
                }
            ]
        },
        {
            "ID": "api_requests",
            "Namespace": "AWS/ApiGateway",
            "MetricName": "Count",
            "Dimensions": [
                {
                    "Name": "ApiName",
                    "Value": api_gateway_public_name
                }
            ]
        },
        {
            "ID": "api_backend_hits",
            "Namespace": "AWS/ApiGateway",
            "MetricName": "CacheHitCount",
            "Dimensions": [
                {
                    "Name": "ApiName",
                    "Value": api_gateway_private_name
                }
            ]
        },
        {
            "ID": "api_backend_misses",
            "Namespace": "AWS/ApiGateway",
            "MetricName": "CacheMissCount",
            "Dimensions": [
                {
                    "Name": "ApiName",
                    "Value": api_gateway_private_name
                }
            ]
        }
        # Add more metrics as needed
    ]

    try:
        for metric in metrics:
            logger.info(f"Processing metric: {metric['ID']}")

            # Retrieve metric data from CloudWatch
            response = cloudwatch.get_metric_statistics(
                Namespace=metric['Namespace'],
                MetricName=metric['MetricName'],
                Dimensions=metric['Dimensions'],
                StartTime=start_time,
                EndTime=end_time,
                Period=86400,  # one day in seconds
                Statistics=['Sum']
            )

            logger.info(f"Response for {metric['ID']}: {response}")

            # Check and store the data in DynamoDB
            if response['Datapoints']:
                count = str(response['Datapoints'][0]['Sum'])
            else:
                count = 0
                logger.error(f"Error during execution: {metric['ID']} had no Datapoints")

            table.put_item(
                Item={
                    'ID': f"{metric['ID']}",
                    'COUNT': count
                }
            )

        table.put_item(
            Item={
                'ID': "timestamp",
                'STARTTIME': formatted_starttime,
                'ENDTIME': formatted_endtime
            }
        )

        # Invalidate the cache after storing all metrics
        invalidate_api_gateway_cache(api_gateway, api_gateway_private_id, 'prod')
        logger.info("Cache invalidated successfully")

        logger.info("Lambda function execution finished successfully")
        return {'statusCode': 200, 'body': 'Data stored successfully for all metrics'}

    except Exception as e:
        logger.error(f"Error during execution: {str(e)}")
        return {'statusCode': 500, 'body': str(e)}

def invalidate_api_gateway_cache(api_gateway_client, api_id, stage_name):
    """
    Invalidate the cache for a specific stage of the REST API Gateway.
    """
    try:
        api_gateway_client.flush_stage_cache(
            restApiId=api_id,
            stageName=stage_name
        )
        logger.info(f"Cache for API Gateway {api_id} at stage {stage_name} invalidated")
    except Exception as e:
        logger.error(f"Error invalidating cache: {str(e)}")