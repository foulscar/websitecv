import http.client
import json
import logging
import os

# Initialize logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Fetching endpoint and path from environment variables
    vpc_endpoint_dns = os.getenv("VPC_ENDPOINT_DNS")
    api_path = os.getenv("API_PATH", "/prod/metrics")

    # Use http.client to create a connection to the REST API
    connection = http.client.HTTPSConnection(vpc_endpoint_dns)

    # Headers that you might need to send with your GET request
    headers = {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache"
    }

    try:
        # Attempt to connect and send the request
        logger.info(f"Connecting to {vpc_endpoint_dns}{api_path}")
        connection.request("GET", api_path, headers=headers)
        response = connection.getresponse()
        response_body = response.read()

        # Log the response status
        logger.info(f"Response received with status: {response.status}")
        
        return {
            'statusCode': response.status,
            'headers': {'Content-Type': 'application/json'},
            'body': response_body.decode('utf-8')
        }

    except Exception as e:
        # Log any exceptions that occur
        logger.error(f"An error occurred: {e}", exc_info=True)
        raise e

    finally:
        # Ensure the connection is closed
        connection.close()
